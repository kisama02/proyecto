import { useState, useEffect } from "react";
import axios from "axios";
import Titulo from "./Titulo";
import ListAlumno from "./ListAlumno";
import FormularioAlumno from "./FormularioAlumno";
import FormularioEditarAlumno from "./FormularioEditarAlumno";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import "../App.css";

const HomePage = () => {
  const [alumnos, setAlumnos] = useState([]);
  const [alumnoEditar, setAlumnoEditar] = useState(null);
  const [showRegistroForm, setShowRegistroForm] = useState(true);

  const URL_API = "http://localhost/API-PHP/";

  useEffect(() => {
    obtenerAlumnos();
  }, []);

  const obtenerAlumnos = async () => {
    try {
      const response = await axios.get(URL_API);
      setAlumnos(response.data);
    } catch (error) {
      console.error("Error al obtener alumnos:", error);
    }
  };

  const eliminarAlumno = async (id) => {
    try {
      await axios.delete(`${URL_API}/?id=${id}`);
      toast.error("Alumno eliminado correctamente.");
      obtenerAlumnos();
    } catch (error) {
      console.error("Error al eliminar alumno:", error);
    }
  };

  const obtenerDatosAlumno = async (id) => {
    try {
      const response = await axios.get(`${URL_API}?id=${id}`);
      setShowRegistroForm(false);
      setAlumnoEditar(response.data);
    } catch (error) {
      console.error("Error al actualizar el alumno:", error);
    }
  };

  const agregarAlumno = async (nuevoAlumno) => {
    try {
      await axios.post(URL_API, nuevoAlumno);
      toast.success("Alumno registrado correctamente.");
      obtenerAlumnos();
    } catch (error) {
      console.error("Error al agregar alumno:", error);
    }
  };

  const handleActualizarAlumno = async (datosAlumno) => {
    try {
      await axios.put(`${URL_API}${datosAlumno.id}`, datosAlumno);
      toast.success("Alumno actualizado correctamente.");
      obtenerAlumnos();
      setShowRegistroForm(true);
    } catch (error) {
      console.error("Error al actualizar los datos del alumno:", error);
    }
  };

  return (
    <>
      <ToastContainer />
      <div className="container my-4">
        <Titulo estado={showRegistroForm} setShowRegistroForm={setShowRegistroForm} />

        <div className="mb-5">
          {showRegistroForm ? (
            <FormularioAlumno agregarAlumno={agregarAlumno} />
          ) : (
            <FormularioEditarAlumno
              alumno={alumnoEditar}
              handleActualizarAlumno={handleActualizarAlumno}
            />
          )}
        </div>

        <div className="mt-5">
          <ListAlumno
            alumnos={alumnos}
            eliminarAlumno={eliminarAlumno}
            obtenerDatosAlumno={obtenerDatosAlumno}
          />
        </div>
      </div>
    </>
  );
};

export default HomePage;
